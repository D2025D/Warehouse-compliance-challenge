# Warehouse Compliance Challenge – v6

Single-file web app (index.html) with:
- Player info gate (Name & Site)
- Final Summary + per-level stats
- Answer logging
- Password-protected leaderboard grouped by site (password: XSite2025!)
- Admin: Clear Leaderboard, Export CSVs

## Easiest ways to get a shareable link

### Netlify Drop (no account)
1) Go to https://app.netlify.com/drop
2) Drag **index.html** into the page.
3) Netlify gives you an instant **https://*.netlify.app** URL you can share.

### GitHub Pages
1) Create a new public repo named e.g. `warehouse-compliance-challenge`.
2) Upload **index.html** to the root of the repo.
3) In repo **Settings → Pages**, set **Source: Deploy from a branch**, branch **main**, folder **/** (root).
4) After it builds, your URL will be: `https://<your-username>.github.io/warehouse-compliance-challenge/`

## Local preview
Just double‑click **index.html** to open in your browser.

## Password
Leaderboard & admin actions use: **XSite2025!**